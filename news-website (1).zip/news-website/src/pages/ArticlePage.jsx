import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';

function ArticlePage() {
  const { id } = useParams();
  const [article, setArticle] = useState(null);

  useEffect(() => {
    axios.get(`https://dummyjson.com/posts/${id}`) // Replace with your backend
      .then(res => setArticle(res.data));
  }, [id]);

  if (!article) return <div className="p-4">Loading...</div>;

  return (
    <div className="max-w-4xl mx-auto p-4">
      <h1 className="text-3xl font-bold mb-4">{article.title}</h1>
      <p className="text-lg">{article.body}</p>
    </div>
  );
}

export default ArticlePage;

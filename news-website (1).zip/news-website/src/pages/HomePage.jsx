import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';

function HomePage() {
  const [news, setNews] = useState([]);

  useEffect(() => {
    axios.get('https://dummyjson.com/posts') // Replace with your backend URL
      .then(res => setNews(res.data.posts));
  }, []);

  return (
    <div className="max-w-6xl mx-auto p-4">
      <h1 className="text-4xl font-bold mb-6">Latest News</h1>
      <div className="grid md:grid-cols-3 gap-4">
        {news.map((article) => (
          <Link to={`/article/${article.id}`} key={article.id} className="bg-white p-4 rounded shadow hover:shadow-lg">
            <h2 className="text-xl font-semibold mb-2">{article.title}</h2>
            <p>{article.body.substring(0, 100)}...</p>
          </Link>
        ))}
      </div>
    </div>
  );
}

export default HomePage;
